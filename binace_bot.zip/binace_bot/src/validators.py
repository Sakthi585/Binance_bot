# src/validators.py
from typing import Literal
from .logger_config import get_logger

logger = get_logger(__name__)

VALID_SIDES = {"BUY", "SELL"}

def validate_symbol(symbol: str) -> str:
    if not symbol or not symbol.upper().endswith("USDT"):
        msg = f"Invalid symbol: {symbol}. Example: BTCUSDT, ETHUSDT."
        logger.error(msg)
        raise ValueError(msg)
    return symbol.upper()

def validate_side(side: str) -> Literal["BUY", "SELL"]:
    s = side.upper()
    if s not in VALID_SIDES:
        msg = f"Invalid side: {side}. Must be BUY or SELL."
        logger.error(msg)
        raise ValueError(msg)
    return s  # type: ignore

def validate_quantity(qty_str: str) -> float:
    try:
        qty = float(qty_str)
    except ValueError:
        msg = f"Quantity must be a number, got: {qty_str}"
        logger.error(msg)
        raise

    if qty <= 0:
        msg = f"Quantity must be positive, got: {qty}"
        logger.error(msg)
        raise ValueError(msg)

    return qty

def validate_price(price_str: str, param_name: str = "price") -> float:
    try:
        price = float(price_str)
    except ValueError:
        msg = f"{param_name} must be a number, got: {price_str}"
        logger.error(msg)
        raise

    if price <= 0:
        msg = f"{param_name} must be positive, got: {price}"
        logger.error(msg)
        raise ValueError(msg)

    return price

def validate_stop_limit_prices(stop_price: float, limit_price: float, side: str):
    # Basic sanity checks only; exact logic can be improved
    if side == "BUY" and stop_price > limit_price * 1.05:
        logger.warning(
            f"BUY stop price {stop_price} is far above limit {limit_price}. Check your inputs."
        )
    if side == "SELL" and stop_price < limit_price * 0.95:
        logger.warning(
            f"SELL stop price {stop_price} is far below limit {limit_price}. Check your inputs."
        )
