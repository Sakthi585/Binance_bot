# src/advanced/twap.py
import sys
import time
from binance.enums import FUTURE_ORDER_TYPE_MARKET
from ..client import get_futures_client
from ..validators import validate_symbol, validate_side, validate_quantity
from ..logger_config import get_logger

logger = get_logger(__name__)

def run_twap(
    symbol: str,
    side: str,
    total_quantity: float,
    slices: int,
    interval_seconds: int,
):
    client = get_futures_client()
    qty_per_slice = total_quantity / slices

    logger.info(
        f"Starting TWAP: symbol={symbol}, side={side}, total_qty={total_quantity}, "
        f"slices={slices}, interval={interval_seconds}s, qty_per_slice={qty_per_slice}"
    )

    for i in range(slices):
        logger.info(f"TWAP slice {i+1}/{slices}: placing MARKET order")
        try:
            resp = client.futures_create_order(
                symbol=symbol,
                side=side,
                type=FUTURE_ORDER_TYPE_MARKET,
                quantity=round(qty_per_slice, 6),
            )
            logger.info(f"TWAP slice {i+1} response: {resp}")
            print(f"✅ Slice {i+1}/{slices} executed")
        except Exception as e:
            logger.exception(f"Error placing TWAP slice {i+1}")
            print(f"❌ Failed slice {i+1}: {e}")
        if i != slices - 1:
            time.sleep(interval_seconds)

def main():
    if len(sys.argv) != 6:
        print(
            "Usage: python -m src.advanced.twap SYMBOL SIDE TOTAL_QTY SLICES INTERVAL_SECONDS"
        )
        print(
            "Example: python -m src.advanced.twap BTCUSDT BUY 0.1 10 30"
        )
        sys.exit(1)

    symbol = validate_symbol(sys.argv[1])
    side = validate_side(sys.argv[2])
    total_qty = validate_quantity(sys.argv[3])

    try:
        slices = int(sys.argv[4])
        interval = int(sys.argv[5])
        if slices <= 0 or interval <= 0:
            raise ValueError
    except ValueError:
        print("SLICES and INTERVAL_SECONDS must be positive integers.")
        sys.exit(1)

    run_twap(symbol, side, total_qty, slices, interval)

if __name__ == "__main__":
    main()
