# src/advanced/oco.py
import sys
from binance.enums import (
    FUTURE_ORDER_TYPE_TAKE_PROFIT,
    FUTURE_ORDER_TYPE_STOP,
    TIME_IN_FORCE_GTC,
)
from ..client import get_futures_client
from ..validators import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price,
)
from ..logger_config import get_logger

logger = get_logger(__name__)

def place_oco_orders(
    symbol: str,
    side: str,
    quantity: float,
    take_profit_price: float,
    stop_loss_price: float,
):
    """
    Simple Futures OCO-like behavior:
    - TAKE_PROFIT limit order
    - STOP limit order
    Both with reduceOnly=True to close an existing position.
    """
    client = get_futures_client()

    logger.info(
        f"Placing OCO orders: symbol={symbol}, side={side}, "
        f"qty={quantity}, TP={take_profit_price}, SL={stop_loss_price}"
    )

    # If you open a BUY position, exit is SELL; if SELL position, exit is BUY.
    exit_side = "SELL" if side == "BUY" else "BUY"

    try:
        tp_resp = client.futures_create_order(
            symbol=symbol,
            side=exit_side,
            type=FUTURE_ORDER_TYPE_TAKE_PROFIT,
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=quantity,
            price=str(take_profit_price),
            reduceOnly=True,
            workingType="MARK_PRICE",
        )

        sl_resp = client.futures_create_order(
            symbol=symbol,
            side=exit_side,
            type=FUTURE_ORDER_TYPE_STOP,
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=quantity,
            price=str(stop_loss_price),
            stopPrice=str(stop_loss_price),
            reduceOnly=True,
            workingType="MARK_PRICE",
        )

        logger.info(f"OCO TP response: {tp_resp}")
        logger.info(f"OCO SL response: {sl_resp}")

        print("✅ OCO (TP + SL) orders placed successfully!")
        print("Take Profit:", tp_resp)
        print("Stop Loss:", sl_resp)

    except Exception as e:
        logger.exception("Error placing OCO orders")
        print(f"❌ Failed to place OCO orders: {e}")

def main():
    if len(sys.argv) != 6:
        print(
            "Usage: python -m src.advanced.oco SYMBOL SIDE QTY TAKE_PROFIT_PRICE STOP_LOSS_PRICE"
        )
        print(
            "Example: python -m src.advanced.oco BTCUSDT BUY 0.001 68000 64000"
        )
        sys.exit(1)

    symbol = validate_symbol(sys.argv[1])
    side = validate_side(sys.argv[2])
    qty = validate_quantity(sys.argv[3])
    tp = validate_price(sys.argv[4], "take_profit_price")
    sl = validate_price(sys.argv[5], "stop_loss_price")

    place_oco_orders(symbol, side, qty, tp, sl)

if __name__ == "__main__":
    main()
