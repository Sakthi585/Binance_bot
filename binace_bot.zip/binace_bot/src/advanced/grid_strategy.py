# src/advanced/grid_strategy.py
import sys
from binance.enums import FUTURE_ORDER_TYPE_LIMIT, TIME_IN_FORCE_GTC
from ..client import get_futures_client
from ..validators import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price,
)
from ..logger_config import get_logger

logger = get_logger(__name__)

def setup_grid(
    symbol: str,
    side: str,
    quantity: float,
    lower_price: float,
    upper_price: float,
    levels: int,
):
    """
    Simple static grid:
    - If side=BUY: place BUY limit orders at grid levels inside [lower, upper].
    - If side=SELL: place SELL limit orders at grid levels.
    """
    client = get_futures_client()
    if levels < 2:
        raise ValueError("Levels must be at least 2")

    step = (upper_price - lower_price) / (levels - 1)
    prices = [lower_price + i * step for i in range(levels)]

    logger.info(
        f"Setting up GRID: symbol={symbol}, side={side}, qty={quantity}, "
        f"lower={lower_price}, upper={upper_price}, levels={levels}, step={step}"
    )

    for i, p in enumerate(prices, start=1):
        price_rounded = round(p, 2)
        logger.info(f"Placing grid order {i}/{levels} at price {price_rounded}")
        try:
            resp = client.futures_create_order(
                symbol=symbol,
                side=side,
                type=FUTURE_ORDER_TYPE_LIMIT,
                timeInForce=TIME_IN_FORCE_GTC,
                quantity=quantity,
                price=str(price_rounded),
            )
            logger.info(f"Grid order {i} response: {resp}")
            print(f"✅ Grid order {i}/{levels} placed at {price_rounded}")
        except Exception as e:
            logger.exception(f"Error placing grid order {i} at price {price_rounded}")
            print(f"❌ Failed to place grid order {i} at {price_rounded}: {e}")

def main():
    if len(sys.argv) != 7:
        print(
            "Usage: python -m src.advanced.grid_strategy SYMBOL SIDE QTY LOWER_PRICE UPPER_PRICE LEVELS"
        )
        print(
            "Example: python -m src.advanced.grid_strategy BTCUSDT BUY 0.001 60000 70000 5"
        )
        sys.exit(1)

    symbol = validate_symbol(sys.argv[1])
    side = validate_side(sys.argv[2])
    qty = validate_quantity(sys.argv[3])
    lower = validate_price(sys.argv[4], "lower_price")
    upper = validate_price(sys.argv[5], "upper_price")

    if upper <= lower:
        print("UPPER_PRICE must be greater than LOWER_PRICE.")
        sys.exit(1)

    try:
        levels = int(sys.argv[6])
        if levels < 2:
            raise ValueError
    except ValueError:
        print("LEVELS must be an integer >= 2.")
        sys.exit(1)

    setup_grid(symbol, side, qty, lower, upper, levels)

if __name__ == "__main__":
    main()
