# src/advanced/stop_limit_orders.py
import sys
from binance.enums import FUTURE_ORDER_TYPE_STOP, TIME_IN_FORCE_GTC
from ..client import get_futures_client
from ..validators import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price,
    validate_stop_limit_prices,
)
from ..logger_config import get_logger

logger = get_logger(__name__)

def place_stop_limit_order(
    symbol: str,
    side: str,
    quantity: float,
    stop_price: float,
    limit_price: float,
):
    client = get_futures_client()
    validate_stop_limit_prices(stop_price, limit_price, side)

    logger.info(
        f"Placing STOP-LIMIT order: symbol={symbol}, side={side}, "
        f"qty={quantity}, stop={stop_price}, limit={limit_price}"
    )

    try:
        resp = client.futures_create_order(
            symbol=symbol,
            side=side,
            type=FUTURE_ORDER_TYPE_STOP,
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=quantity,
            price=str(limit_price),
            stopPrice=str(stop_price),
            workingType="MARK_PRICE",
        )
        logger.info(f"Stop-limit order response: {resp}")
        print("✅ Stop-limit order placed successfully!")
        print(resp)
    except Exception as e:
        logger.exception("Error placing stop-limit order")
        print(f"❌ Failed to place stop-limit order: {e}")

def main():
    if len(sys.argv) != 6:
        print(
            "Usage: python -m src.advanced.stop_limit_orders SYMBOL SIDE QTY STOP_PRICE LIMIT_PRICE"
        )
        print(
            "Example: python -m src.advanced.stop_limit_orders BTCUSDT BUY 0.001 64000 64500"
        )
        sys.exit(1)

    symbol = validate_symbol(sys.argv[1])
    side = validate_side(sys.argv[2])
    qty = validate_quantity(sys.argv[3])
    stop_price = validate_price(sys.argv[4], "stop_price")
    limit_price = validate_price(sys.argv[5], "limit_price")

    place_stop_limit_order(symbol, side, qty, stop_price, limit_price)

if __name__ == "__main__":
    main()
