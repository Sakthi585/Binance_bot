# src/config.py
from dotenv import load_dotenv
import os

load_dotenv()

BINANCE_API_KEY = os.getenv("BINANCE_API_KEY")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET")
USE_TESTNET = os.getenv("BINANCE_FUTURES_TESTNET", "true").lower() == "true"

TESTNET_FUTURES_URL = "https://testnet.binancefuture.com"
MAINNET_FUTURES_URL = "https://fapi.binance.com"

FUTURES_BASE_URL = TESTNET_FUTURES_URL if USE_TESTNET else MAINNET_FUTURES_URL
