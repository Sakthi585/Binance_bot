# src/limit_orders.py
import sys
from binance.enums import FUTURE_ORDER_TYPE_LIMIT, TIME_IN_FORCE_GTC
from .client import get_futures_client
from .validators import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price,
)
from .logger_config import get_logger

logger = get_logger(__name__)

def place_limit_order(symbol: str, side: str, quantity: float, price: float):
    client = get_futures_client()
    logger.info(
        f"Placing LIMIT order: symbol={symbol}, side={side}, qty={quantity}, price={price}"
    )

    try:
        resp = client.futures_create_order(
            symbol=symbol,
            side=side,
            type=FUTURE_ORDER_TYPE_LIMIT,
            timeInForce=TIME_IN_FORCE_GTC,
            quantity=quantity,
            price=str(price),
        )
        logger.info(f"Limit order response: {resp}")
        print("✅ Limit order placed successfully!")
        print(resp)
    except Exception as e:
        logger.exception("Error placing limit order")
        print(f"❌ Failed to place limit order: {e}")

def main():
    if len(sys.argv) != 5:
        print("Usage: python -m src.limit_orders SYMBOL SIDE QTY PRICE")
        print("Example: python -m src.limit_orders BTCUSDT BUY 0.001 65000")
        sys.exit(1)

    symbol = validate_symbol(sys.argv[1])
    side = validate_side(sys.argv[2])
    qty = validate_quantity(sys.argv[3])
    price = validate_price(sys.argv[4])

    place_limit_order(symbol, side, qty, price)

if __name__ == "__main__":
    main()
