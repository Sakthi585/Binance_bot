# src/market_orders.py
import sys
from binance.enums import FUTURE_ORDER_TYPE_MARKET
from .client import get_futures_client
from .validators import validate_symbol, validate_side, validate_quantity
from .logger_config import get_logger

logger = get_logger(__name__)

def place_market_order(symbol: str, side: str, quantity: float):
    client = get_futures_client()
    logger.info(
        f"Placing MARKET order: symbol={symbol}, side={side}, qty={quantity}"
    )
    try:
        resp = client.futures_create_order(
            symbol=symbol,
            side=side,
            type=FUTURE_ORDER_TYPE_MARKET,
            quantity=quantity,
        )
        logger.info(f"Market order response: {resp}")
        print("Market order placed successfully!")

        # 🔽 This part is new (to avoid printing just {})
        if resp:
            print(resp)
       

    except Exception as e:
        logger.exception("Error placing market order")
        print(f" Failed to place market order: {e}")

def main():
    if len(sys.argv) != 4:
        print("Usage: python -m src.market_orders SYMBOL SIDE QTY")
        print("Example: python -m src.market_orders BTCUSDT BUY 0.001")
        sys.exit(1)

    symbol_arg = validate_symbol(sys.argv[1])
    side_arg = validate_side(sys.argv[2])
    qty_arg = validate_quantity(sys.argv[3])

    place_market_order(symbol_arg, side_arg, qty_arg)

if __name__ == "__main__":
    main()
