# src/client.py
from binance.client import Client
from .config import BINANCE_API_KEY, BINANCE_API_SECRET, FUTURES_BASE_URL, USE_TESTNET
from .logger_config import get_logger

logger = get_logger(__name__)

def get_futures_client() -> Client:
    if not BINANCE_API_KEY or not BINANCE_API_SECRET:
        logger.error("API key/secret not set in environment")
        raise RuntimeError("Please set BINANCE_API_KEY and BINANCE_API_SECRET in .env")

    client = Client(api_key=BINANCE_API_KEY, api_secret=BINANCE_API_SECRET)

    if USE_TESTNET:
        # Override futures URL for testnet
        client.FUTURES_URL = FUTURES_BASE_URL
        logger.info("Initialized Binance Futures client (testnet=True)")
    else:
        logger.info("Initialized Binance Futures client (testnet=False)")

    return client
